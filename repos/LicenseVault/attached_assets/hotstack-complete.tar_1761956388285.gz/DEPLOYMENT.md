# 🚀 HotStack Deployment Guide

Complete step-by-step guide to deploy HotStack to Cloudflare.

## Prerequisites Checklist

- [ ] Cloudflare account created
- [ ] Node.js 18+ installed
- [ ] Wrangler CLI installed (`npm install -g wrangler`)
- [ ] Domain (faa.zone) configured in Cloudflare

## Step 1: Initial Setup

```bash
# Navigate to project
cd hotstack

# Install dependencies
npm install

# Login to Cloudflare (opens browser)
wrangler login
```

## Step 2: Create R2 Bucket

```bash
# Create the bucket
wrangler r2 bucket create hotstack-bucket

# Verify creation
wrangler r2 bucket list
```

Expected output:
```
✨ Successfully created bucket 'hotstack-bucket'
```

## Step 3: Create Queue

```bash
# Create the queue
wrangler queues create hotstack-upload-queue

# Verify creation
wrangler queues list
```

Expected output:
```
✨ Successfully created queue 'hotstack-upload-queue'
```

## Step 4: Set Secrets

```bash
# Set backend API token
wrangler secret put BACKEND_API_TOKEN
# Enter your token when prompted

# Set backend URL
wrangler secret put BACKEND_BASE_URL
# Enter: https://fruitful-global-central-backend-hub.heynsschoeman.repl.co
```

## Step 5: Configure Routes

Edit `wrangler.toml` to match your domain:

```toml
routes = [
  { pattern = "fruitful.faa.zone/hotstack/*", zone_name = "faa.zone" },
  { pattern = "hotstack.faa.zone/*", zone_name = "faa.zone" }
]
```

**Important**: Ensure `faa.zone` is added to your Cloudflare account.

## Step 6: Test Locally

```bash
# Start dev server
npm run dev
```

Visit http://localhost:8787 and test:
1. Upload a file
2. Check `/status` endpoint
3. Verify upload works

## Step 7: Deploy to Development

```bash
# Deploy
npm run deploy

# Tail logs to verify
npm run tail
```

Expected output:
```
✨ Uploaded hotstack-worker
✨ Deployment complete!
```

## Step 8: Test Production

Test your endpoints:

```bash
# Check status
curl https://hotstack.faa.zone/status

# Test upload (replace with actual file)
curl -X POST https://hotstack.faa.zone/upload \
  -F "file=@test.zip"
```

## Step 9: Deploy to Production Environment

```bash
# Deploy production
npm run deploy:production

# Tail production logs
wrangler tail --env production
```

## Step 10: Configure DNS (if needed)

In Cloudflare DNS for `faa.zone`:

1. **For `hotstack.faa.zone`**:
   - Type: `CNAME`
   - Name: `hotstack`
   - Target: Your worker route (automatic via wrangler)
   - Proxy: Enabled (orange cloud)

2. **For `fruitful.faa.zone/hotstack`**:
   - Already covered by route pattern

## Verification Checklist

After deployment, verify:

- [ ] https://hotstack.faa.zone loads upload UI
- [ ] https://hotstack.faa.zone/status returns JSON
- [ ] https://hotstack.faa.zone/health returns "OK"
- [ ] File upload works end-to-end
- [ ] Queue messages are processing (check `wrangler tail`)
- [ ] Backend receives intake requests

## Monitoring

### View Real-Time Logs

```bash
# Development
wrangler tail

# Production
wrangler tail --env production
```

### Check Cloudflare Dashboard

1. Go to https://dash.cloudflare.com
2. Select your account
3. Navigate to Workers & Pages
4. Click on `hotstack-worker`
5. View metrics, logs, and analytics

### Monitor R2 Usage

```bash
# List objects in bucket
wrangler r2 object list hotstack-bucket

# Get bucket info
wrangler r2 bucket list
```

### Monitor Queue

1. Go to Cloudflare Dashboard
2. Navigate to Queues
3. Click `hotstack-upload-queue`
4. View depth, throughput, and errors

## Updating

To deploy updates:

```bash
# Make your changes
# Then deploy
npm run deploy

# Or for production
npm run deploy:production
```

## Rollback

If something goes wrong:

```bash
# List deployments
wrangler deployments list

# Rollback to previous version
wrangler rollback [DEPLOYMENT_ID]
```

## Common Issues

### Issue: "Bucket not found"

**Solution**: Ensure bucket is created and name matches in `wrangler.toml`

```bash
wrangler r2 bucket create hotstack-bucket
```

### Issue: "Queue not found"

**Solution**: Create the queue

```bash
wrangler queues create hotstack-upload-queue
```

### Issue: "Route not applied"

**Solution**: 
1. Verify domain is in Cloudflare
2. Check zone_name in wrangler.toml
3. Redeploy

### Issue: "Backend not receiving requests"

**Solution**:
1. Check `BACKEND_BASE_URL` secret
2. Verify `BACKEND_API_TOKEN` is set
3. Check backend logs on Replit
4. View worker logs with `wrangler tail`

### Issue: "CORS errors"

**Solution**: CORS is already configured in worker. Verify:
1. Request has correct origin
2. Preflight OPTIONS request works
3. Headers are correct

## Performance Optimization

### Enable Caching

Static assets are already cached (1 hour). Adjust in worker code:

```javascript
'Cache-Control': 'public, max-age=3600'
```

### Monitor Cold Starts

Check response times in Cloudflare dashboard. Consider:
- Using Durable Objects for state
- Implementing warming strategy

### Scale Queue Processing

Adjust in `wrangler.toml`:

```toml
[[queues.consumers]]
queue = "hotstack-upload-queue"
max_batch_size = 20        # Increase batch size
max_batch_timeout = 60     # Increase timeout
```

## Security Best Practices

1. **Rotate Secrets Regularly**
```bash
wrangler secret put BACKEND_API_TOKEN
```

2. **Limit File Upload Size**
Already set to 10MB in worker code.

3. **Validate File Types**
Already implemented in worker.

4. **Monitor Usage**
Set up Cloudflare alerts for:
- High error rates
- Unusual traffic
- R2 storage limits

## Cost Monitoring

### Free Tier Limits (Cloudflare)

- **Workers**: 100,000 requests/day
- **R2**: 10 GB storage, 1M reads/month
- **Queues**: 1M operations/month

### Check Usage

```bash
# R2 usage
wrangler r2 bucket list

# Worker usage - check dashboard
```

## Next Steps

1. Set up monitoring alerts
2. Configure backup strategy for R2
3. Implement rate limiting if needed
4. Add analytics/tracking
5. Set up CI/CD pipeline

## Support

Issues? Contact:
- Email: heynsschoeman@gmail.com
- GitHub Issues: https://github.com/heyns1000/hotstack

---

**🔥 HotStack is now live!**

Visit: https://hotstack.faa.zone

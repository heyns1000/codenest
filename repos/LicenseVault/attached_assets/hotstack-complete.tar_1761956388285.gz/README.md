# 🔥 HotStack - Omnidrop File Intake System

**Rapid file deployment infrastructure powered by Cloudflare Workers + R2**

## Overview

HotStack is a high-performance file intake system that processes uploads through Cloudflare's edge network, stores them in R2, and triggers backend processing via queues.

### Key Features

- ⚡ **3-Minute Rule**: Rapid deployment pipeline
- 📦 **R2 Storage**: Cloudflare object storage with global edge delivery
- 🔄 **Queue Processing**: Async backend integration for reliability
- 🌍 **Edge Computing**: Cloudflare Workers for low-latency uploads
- 🎨 **Beautiful UI**: Tailwind CSS with animated interface
- 🔒 **Secure**: CORS-enabled with validation

## Architecture

```
┌─────────────┐
│   Browser   │
└──────┬──────┘
       │ Upload File
       ▼
┌─────────────────┐
│ Cloudflare Edge │
│  (Worker)       │ ◄── You are here
└────────┬────────┘
         │
         ├─► R2 Bucket (hotstack-bucket)
         │
         └─► Queue (hotstack-upload-queue)
                  │
                  ▼
         ┌──────────────────┐
         │ Backend Processor │
         │  (Replit)         │
         └──────────────────┘
```

## Project Structure

```
hotstack/
├── src/
│   └── index.js          # Main worker code
├── public/
│   └── index.html        # Standalone upload UI
├── wrangler.toml         # Cloudflare configuration
├── package.json          # Dependencies
└── README.md            # This file
```

## Setup

### Prerequisites

- Node.js 18+ installed
- Cloudflare account
- Wrangler CLI installed globally

### Installation

```bash
# Clone or navigate to project
cd hotstack

# Install dependencies
npm install

# Login to Cloudflare
wrangler login

# Create R2 bucket (if not exists)
wrangler r2 bucket create hotstack-bucket

# Create queue (if not exists)
wrangler queues create hotstack-upload-queue

# Set secrets
wrangler secret put BACKEND_API_TOKEN
wrangler secret put BACKEND_BASE_URL
```

### Development

```bash
# Start local dev server
npm run dev

# Visit: http://localhost:8787
```

### Deployment

```bash
# Deploy to development
npm run deploy

# Deploy to production
npm run deploy:production

# View logs
npm run tail
```

## Configuration

### Environment Variables

Set these via `wrangler secret put`:

- `BACKEND_API_TOKEN`: Authentication token for backend
- `BACKEND_BASE_URL`: Backend endpoint (e.g., https://your-backend.repl.co)

### Routes

Configured in `wrangler.toml`:

- `fruitful.faa.zone/hotstack/*`
- `hotstack.faa.zone/*`

## API Endpoints

### POST /upload

Upload a file to R2.

**Request:**
```
Content-Type: multipart/form-data

file: <binary file data>
```

**Response:**
```json
{
  "success": true,
  "message": "File uploaded successfully",
  "data": {
    "fileName": "example.zip",
    "size": 1024000,
    "sizeFormatted": "1000.00 KB",
    "key": "uploads/1234567890_example.zip",
    "contentType": "application/zip",
    "timestamp": 1234567890
  }
}
```

### GET /status

Check worker status.

**Response:**
```json
{
  "status": "operational",
  "worker": "hotstack-worker",
  "version": "1.0.0",
  "environment": "production",
  "services": {
    "r2": true,
    "queue": true,
    "backend": true
  }
}
```

### GET /health

Simple health check.

**Response:**
```
OK
```

## File Upload Limits

- **Max File Size**: 10 MB
- **Allowed Types**:
  - Archives: `.zip`
  - Spreadsheets: `.xlsx`, `.xls`
  - Images: `.png`, `.jpg`, `.jpeg`
  - Documents: `.pdf`, `.txt`, `.html`
  - Code: `.js`, `.json`

## Queue Processing

When a file is uploaded:

1. File is stored in R2
2. Event is queued with metadata
3. Queue consumer triggers backend processing
4. Backend categorizes and indexes the file

### Queue Message Format

```json
{
  "bucket": "hotstack-bucket",
  "key": "uploads/1234567890_file.zip",
  "size": 1024000,
  "contentType": "application/zip",
  "timestamp": 1234567890,
  "fileName": "file.zip"
}
```

## Backend Integration

The worker integrates with a backend processor (e.g., Replit) that:

- Receives file metadata via POST to `/api/hotstack/intake`
- Downloads file from R2
- Extracts and categorizes content
- Updates database/index
- Returns processing results

### Backend Endpoint Contract

**POST** `/api/hotstack/intake`

Headers:
```
Content-Type: application/json
Authorization: Bearer {BACKEND_API_TOKEN}
```

Body:
```json
{
  "bucket": "hotstack-bucket",
  "key": "uploads/1234567890_file.zip",
  "size": 1024000,
  "etag": "d41d8cd98f00b204e9800998ecf8427e",
  "timestamp": 1234567890,
  "source": "hotstack-worker"
}
```

Expected Response:
```json
{
  "success": true,
  "message": "File processed successfully",
  "data": {
    "brands": 5,
    "files": 127,
    "processingTime": 2.34
  }
}
```

## Monitoring

### View Logs

```bash
# Real-time logs
wrangler tail

# Production logs
wrangler tail --env production
```

### Metrics

Check Cloudflare dashboard for:
- Request count
- Error rate
- Bandwidth usage
- R2 storage usage
- Queue depth

## Troubleshooting

### Upload fails with 400

- Check file size (max 10MB)
- Verify file type is allowed
- Ensure file is properly attached

### Queue messages not processing

- Check backend is running
- Verify `BACKEND_API_TOKEN` is set
- Check `BACKEND_BASE_URL` is correct
- View queue dashboard in Cloudflare

### 500 errors

- Check worker logs: `wrangler tail`
- Verify R2 bucket exists
- Ensure queue is created

## Development Tips

### Local Testing

```bash
# Run locally with hot reload
npm run dev

# Test upload
curl -X POST http://localhost:8787/upload \
  -F "file=@test.zip"

# Check status
curl http://localhost:8787/status
```

### Testing Queue Processing

Queue processing only works in deployed environment. Use `wrangler tail` to see queue messages.

## Links

- **Live Upload**: https://hotstack.faa.zone
- **Status Check**: https://hotstack.faa.zone/status
- **Cloudflare Dashboard**: https://dash.cloudflare.com
- **R2 Documentation**: https://developers.cloudflare.com/r2
- **Workers Documentation**: https://developers.cloudflare.com/workers

## License

MIT © Heyns Schoeman

## Support

For issues or questions:
- Email: heynsschoeman@gmail.com
- GitHub: https://github.com/heyns1000

---

**Powered by Fruitful Global | ScrollSynced | Vault-Verified**

🦍 Banimal Ecosystem | 🍝 Noodle Juice Flow | 🗄️ Vault Allocation
